#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcs1.h"
#include "tests1.h"

int
main(void)
{
    interface();
    ask();
    return 0;
}
