#!/bin/bash
rm *.info
rm *.css
rm *.html
rm *.png
rm *.gcda
rm *.gcno
rm -rf TRY
rm *.out
rm -rf lcov
